# Créditos y licencia de las imágenes

Vistas de referencia y objetivo: [nuScenes](https://www.nuscenes.org/nuscenes), © Motional AD Inc. y sus afiliadas. Se comparten para uso académico no comercial bajo [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) y los [términos de uso de nuScenes](https://www.nuscenes.org/terms-of-use).

La muestra incluye un objetivo del piloto (scene-0045), sus referencias y nueve reconstrucciones. Las vistas de evaluación se redimensionaron a 768 × 432 con Lanczos. Se añadieron miniaturas, métricas y mapas de error de píxel. Las adaptaciones de los datos se distribuyen bajo la misma licencia; este aviso no cambia la licencia del código del visor.

El TFG es independiente y no implica respaldo de Motional.
